package com.alejfneto.desafio_01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Desafio01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
